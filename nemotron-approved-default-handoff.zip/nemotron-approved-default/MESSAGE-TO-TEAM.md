Subject: Make the approved Nemotron pronunciation the voice agent default

Hi team,

I’ve selected **8A-6** as the target pronunciation. Please use the attached full-phrase and standalone-word recordings as the reference and make this the voice agent’s default:

- Say **Nemotron** with the same “Nimo” sound as the reference, as one compact, quick word. Apply this wherever Nemotron appears, including when the word is spoken alone.
- Say **Nemotron 3 Diarization** as a connected product name, with a very short transition before “three.” Keep the rest of the sentence at its normal pace.

For calibration, 8A-6 speeds up the Nemotron segment by about **28% relative to 8A** (roughly **0.81 → 0.63 seconds**) and removes another **90 ms** of silence before “three.” The attached recording is the acceptance reference.

Please put this in the shared pronunciation/TTS configuration so it persists across sessions. The reference was created with audio timing edits; the team should reproduce its sound using controls supported by the deployed TTS engine. IPA alone should not be treated as the timing fix.

Please send back a live preview of “Nemotron,” “This is Nemotron,” and “Nemotron 3 Diarization” in the default voice, plus a sentence containing the product name. Also verify the behavior in a fresh session before making it the default.

Thanks!
