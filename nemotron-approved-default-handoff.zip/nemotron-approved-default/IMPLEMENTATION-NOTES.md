# Approved Nemotron pronunciation reference: 8A-6

The user selected **8A-6**: “8A-6 is good the fastest are the best.” This is the approved listening reference for the requested default. The live agent has not been changed.

## Requested behavior

1. Give the canonical term **Nemotron** a consistent “Nimo” sound and compact delivery wherever it occurs: alone, in a sentence, or in a longer product name.
2. Match the connected flow of **Nemotron 3 Diarization** in the approved phrase. Render the number as “three” in this product name.
3. Make the rule part of the agent’s persisted default pronunciation configuration and load it for new sessions. Keep displayed text spelled **Nemotron**.

The reference has two independent properties: the pronunciation sounds and the timing. A dictionary/IPA entry can pin the sounds when supported. Reproducing the faster word and shorter join also requires suitable prosody/timing behavior. The 1.28 value below is an offline audio-edit parameter, not a verified TTS request parameter.

## Files and exact calibration

| File | Purpose |
|---|---|
| `approved-8A-6-phrase.wav` | Approved full-context recording: “This is Nemotron three Diarization.” |
| `approved-nemotron-word.wav` | The exact edited word samples used inside the phrase, extracted for easy comparison |
| `reference-baseline-8A.wav` | The preceding user-selected recording; defines the baseline for the relative tempo/pause changes |
| `approved-selection.json` | User decision, measured timings, editing provenance, SHA-256 hashes and ASR model |
| `MESSAGE-TO-TEAM.md` | Ready-to-send request |

- Reference voice: **Chris**, from the historical recordings. Match the target in the deployed default voice; audition each additional supported voice before applying the same parameters globally.
- Word interval in baseline 8A: **0.4700–1.2800 s**.
- Pitch-preserving word tempo setting: **1.28×**. Actual interval: **0.80998 → 0.62993 s**, saving **180.05 ms**. The small difference between the requested and measured ratio comes from the time-stretch implementation.
- Additional quiet material removed before “three”: **90.02 ms relative to 8A**. 8A already removed 120 ms from the historical #8 source, so the cumulative quiet reduction is about **210 ms** relative to that original.
- Remaining measured quiet core before “three”: about **25 ms**. This is a measurement of the reference, not a universal silence setting for every context or voice.
- Whole phrase: **2.30345 s**. Prefix “This is” and the suffix “three Diarization” retain the baseline samples and pace. Word boundaries use approximately 4 ms edge blends; the quiet splice uses approximately a 2 ms crossfade.
- Original synthesis seed and temperature are unknown. This selection does not establish new seed/temperature values or an approved IPA string.

## Implementation and acceptance

Use the attached sound as the acceptance reference. Map it to the deployed engine’s supported pronunciation and word-level timing controls. Verify the engine/model/version capabilities before selecting a mechanism. If word-level rate control is unavailable, evaluate a dedicated TTS adapter treatment or an approved term-audio path, checking voice consistency and joins. Do not apply the recording’s fixed cut timestamps to newly generated speech.

The public blueprint documents `TTS_IPA_FILE_PATH` for a JSON/YAML word→IPA dictionary, wired into `NvidiaTTSService(custom_dictionary=load_ipa_dictionary())`. Its guide calls for restarting the server/reapplying the Compose configuration after changing the dictionary, then starting a new session. See the [official TTS configuration guide](https://github.com/NVIDIA-AI-Blueprints/nemotron-voice-agent/blob/main/docs/how-to/configure-tts.md).

The current [NVIDIA NIM customization guide](https://docs.nvidia.com/nim/speech/latest/tts/customization.html) documents `phoneme` and `say-as` SSML tags; it does not establish `prosody rate` or `break` support. Avoid promising that a word-level SSML speed tag implements this change. The blueprint also documents a default text filter that strips the opening `<` character. These public documents do not verify which model/version or adapter wiring the deployed Astra app uses.

Accept the change when:

- Live output retains the selected “Nimo” vowel quality and makes Nemotron a compact word, with pacing comparable to the approved standalone sample.
- The full product name flows naturally into “three,” with the onset of “three” intact and no added syllable breaks.
- The rule works for “Nemotron,” “This is Nemotron,” “Nemotron 3 Diarization,” and a longer sentence containing the name. The surrounding sentence keeps its normal pace.
- A new session loads the default; existing sessions use the new rule only after the TTS adapter has actually applied it. The deployed preview is auditioned before rollout.

Verification already performed on the reference: **NVIDIA Parakeet TDT 0.6B v3** through `mlx-community/parakeet-tdt-0.6b-v3` transcribed the full clip as “This is Nemotron three diarization.” It transcribed the isolated word as “Nemo Tron.” These are content checks; the user’s listening selection establishes the preferred pronunciation. Waveform checks confirmed no clipping and preserved surrounding audio.
